
//creates image
function createImage(src){
  var img = document.createElement("IMG");
   img.src = src;
   document.body.appendChild(img);
   img.onclick = function(){
   console.log("the user just clicked on the image");
   img.style.opacity = 0.5;
   
   }
}

//app initialise
function loadApp(){
  console.log("Page Loaded");
  //calling create image function with src attribute
  createImage("./img/bg1.jpg");
}

window.onload = loadApp;
