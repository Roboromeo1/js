//creates h1
function createHeading1(titleText){
  var h1 = document.createElement('H1');
  var t = document.createTextNode(titleText);
    h1.appendChild(t);
    document.body.appendChild(h1);

}

//creates h2
function createHeading2(titleText){
  var h2 = document.createElement('H2');
  var t = document.createTextNode(titleText);
    h2.appendChild(t);
    document.body.appendChild(h2);

}


//creates h3
function createHeading3(titleText){
  var h1 = document.createElement('H3');
  var t = document.createTextNode(titleText);
    h3.appendChild(t);
    document.body.appendChild(h3);

}



//creates p
function createParagraph(){
  var p = document.createElement('p');
  document.body.appendChild(p);
    p.classList.add("paraText");

}


//intitailise when window is loaded
function startup(){
  console.log('startup code running');
  createHeading1("my h1 Text");
  createHeading2("my h2 Text");
  createHeading2("my h3 Text");
  createParagraph();

}
window.onload = startup;
