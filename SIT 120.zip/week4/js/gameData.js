window.gameLevels = {
  "Room A": {
    description:"This is Starting Room",
    connectTo:"Library"
  },
  "Library": {
    description:"This is Library",
    connect:"Room A"

  }
};
