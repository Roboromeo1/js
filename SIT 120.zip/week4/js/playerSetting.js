window.playerSetting = {
  name:"Adhitya Ram",
  height:160,
  location:"room A"
};
