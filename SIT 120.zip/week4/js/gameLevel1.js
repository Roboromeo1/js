window.gameLevel1 = [
  {
    question:"What is the capital of Austrilia?",
    answer : "Canberra"

  },
  {
    question : "What i sthe capital of USA?",
    answer: "Washington"
  }
];
