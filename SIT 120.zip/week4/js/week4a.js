
//creates p
function createParagraph(titleText){
  var p = document.createElement('P');
  var t = document.createTextNode(titleText);
    p.appendChild(t);
    document.body.appendChild(p);

}

 function configureGameUi(){

//display player name  on paragraph
  var name = createParagraph("Player Name:  " + playerSetting.name);
//display location on paragraph
  var location =  createParagraph("Players Location : " +playerSetting.location);



}
//check display name before displaying
function displayPlayerName() {
console.log(playerSetting.name);

}
//checks to display location before displaying
function displayCurrentLocation(){
console.log(playerSetting.location);
console.log(gameLevels);
}

function playerNameElement(){

}
function loadApp(){
    document.body.innerHTML ="";
    console.log("Load app");
    configureGameUi();
    displayPlayerName();
    displayCurrentLocation();

}
// ensure when loadpp function loads when window has loaded.

window.onload = loadApp;
