var currentColor = "";
//function to generate randon number
function randomNumber(){
  myRand = Math.ceil(Math.random()*4);
  return myRand;
}

//fucntion to change backgroundcolor
function changeBg(){
  var cc = document.bgColor;
  document.bgColor = ColourList[randomNumber()];
  console.log('color Changed from ' + cc);

}

//fucntion to create a html Button

function createButton(buttonText){
  var element = document.createElement("BUTTON");
  var t = document.createTextNode(buttonText);
   element.appendChild(t);
   document.body.appendChild(element);
   element.id = 'mybutton';
}

function appLoad(){
  document.body.html="";
  //ensure that window is loaded
  console.log("App Load");
  //create html tag to change colour
  createButton('Change Colour');
//chnages background when button is clicked
  document.getElementById('mybutton').onclick = changeBg;

}

//to load window
window.onload = appLoad;
